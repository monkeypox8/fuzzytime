# fuzzytime
Fuzzy time widget for übersicht.

This widget will display time like "Quarter After Five" and "Twenty To Six"

Edit index.coffee to customize
